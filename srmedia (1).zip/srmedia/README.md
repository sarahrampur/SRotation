# srmedia

A landing page showing the book on your Goodreads Currently Reading shelf, the newest video on your YouTube playlist, and the last song on your Apple Music playlist. It refreshes about every 15 minutes. No sign-ins, API keys or secrets are needed.

## Before you start

- Your Goodreads profile must be public, or the shelf feed returns nothing.
- Your YouTube playlist must be **Public** or **Unlisted**. Private playlists have no feed.
- Your Apple Music playlist must stay shared.

## Deploy to Vercel

Push this folder to GitHub and import it at [vercel.com/new](https://vercel.com/new), or run `npx vercel` here. Leave the build settings at their defaults.

## Pointing at your playlist

The YouTube playlist ID is set in `lib/youtube.js`. To change it without editing code, add `YOUTUBE_PLAYLIST_ID` in Vercel under Settings > Environment Variables, then redeploy. The ID is everything after `list=` in the playlist's link.

## Changing things

- The name in the sentence: `data-name` on `<body>` in `public/index.html`, plus the page title and description there.
- Other sources: set `GOODREADS_USER_ID` or `APPLE_PLAYLIST_URL` in Vercel.

## Known limits

- YouTube's playlist feed holds up to 15 videos in the playlist's own order, and the page shows the first one. Add new videos to the top of the playlist so the newest one is shown. The "Added" date is the date YouTube gives for that video in the feed.
- Apple's public playlist page only includes the first 100 tracks or so. Past that, the song shown will be the last one on that page rather than the true last track.
