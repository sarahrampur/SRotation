import test from "node:test";
import assert from "node:assert/strict";
import { parseCurrentlyReading } from "../lib/goodreads.js";
import { parsePlaylistFeed } from "../lib/youtube.js";
import { findLastSongUrl, parseSong } from "../lib/apple.js";

const song = (slug, id) => `https://music.apple.com/us/song/${slug}/${id}`;

test("picks the most recently added book and enlarges its cover", () => {
  const xml = `<rss><channel><title>shelf</title>
    <item><title><![CDATA[Older & Wiser]]></title><book_id>1</book_id><author_name>A</author_name>
      <book_large_image_url><![CDATA[https://x/1.jpg]]></book_large_image_url>
      <user_date_added><![CDATA[Mon, 01 Jan 2024 10:00:00 -0800]]></user_date_added></item>
    <item><title><![CDATA[Newest & Best]]></title><book_id>2</book_id><author_name>B</author_name>
      <book_large_image_url><![CDATA[https://x/2._SY475_.jpg]]></book_large_image_url>
      <user_date_added><![CDATA[Mon, 01 Jan 2026 10:00:00 -0800]]></user_date_added></item>
  </channel></rss>`;
  assert.deepEqual(parseCurrentlyReading(xml), {
    title: "Newest & Best",
    author: "B",
    cover: "https://x/2.jpg",
    url: "https://www.goodreads.com/book/show/2",
  });
});

test("handles an empty shelf and a placeholder cover", () => {
  assert.equal(parseCurrentlyReading("<rss><channel></channel></rss>"), null);
  const xml = `<item><title>T</title><book_id>3</book_id><book_large_image_url>https://x/nophoto/book.png</book_large_image_url></item>`;
  assert.equal(parseCurrentlyReading(xml).cover, null);
});

test("reads the first entry of the playlist feed", () => {
  const xml = `<feed><title>srmedia</title>
    <entry><yt:videoId>dQw4w9WgXcQ</yt:videoId><title>Tom &amp; Jerry</title>
      <author><name>Some Channel</name><uri>x</uri></author><published>2026-11-03T12:00:00+00:00</published></entry>
    <entry><yt:videoId>aaaaaaaaaaa</yt:videoId><title>Second</title></entry></feed>`;
  const video = parsePlaylistFeed(xml);
  assert.equal(video.id, "dQw4w9WgXcQ");
  assert.equal(video.title, "Tom & Jerry");
  assert.equal(video.channel, "Some Channel");
  assert.equal(video.added, "Nov 3, 2026");
  assert.equal(video.url, "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  assert.equal(parsePlaylistFeed("<feed></feed>"), null);
  assert.equal(parsePlaylistFeed("<entry><yt:videoId>bad</yt:videoId></entry>"), null);
});

test("takes the final track from page data, ignoring other sections", () => {
  const data = [{ data: { sections: [
    { itemKind: "trackLockup", items: [
      { contentDescriptor: { url: song("first", 1) } },
      { contentDescriptor: { url: song("last", 2) } },
    ] },
    { itemKind: "squareLockup", items: [{ contentDescriptor: { url: song("promo", 3) } }] },
  ] } }];
  const html = `<script type="application/json" id="serialized-server-data">${JSON.stringify(data)}</script>`;
  assert.equal(findLastSongUrl(html), song("last", 2));
});

test("falls back to schema data, then meta tags", () => {
  const schema = `<script id=schema:music-playlist type="application/ld+json">${JSON.stringify({ track: [{ url: song("a", 1) }, { url: song("b", 2) }] })}</script>`;
  assert.equal(findLastSongUrl(schema), song("b", 2));
  const meta = `<meta property="music:song" content="${song("a", 1)}"><meta content="${song("rooster", 157317003)}" property="music:song">`;
  assert.equal(findLastSongUrl(meta), song("rooster", 157317003));
  assert.equal(findLastSongUrl("<html></html>"), null);
});

test("builds the song from the catalog lookup, or from its link alone", () => {
  const url = song("rooster", 157317003);
  const full = parseSong(url, { results: [{ trackName: "Rooster", artistName: "Alice In Chains", collectionName: "Dirt", artworkUrl100: "https://a/100x100bb.jpg", previewUrl: "https://p" }] });
  assert.equal(full.artist, "Alice In Chains");
  assert.equal(full.artwork, "https://a/800x800bb.jpg");
  assert.equal(parseSong(url, { results: [] }).title, "Rooster");
});
