const name = document.body.dataset.name;
const $ = (id) => document.getElementById(id);

const PLAY = '<svg viewBox="0 0 10 10" aria-hidden="true"><path d="M1 0l9 5-9 5z"/></svg>';
const PAUSE = '<svg viewBox="0 0 10 10" aria-hidden="true"><path d="M1 0h3v10H1zM6 0h3v10H6z"/></svg>';

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function shorten(text, words = 7) {
  const parts = text.split(/\s+/);
  return parts.length > words ? `${parts.slice(0, words).join(" ")}…` : text;
}

function caption(id, title, detail, url) {
  const heading = url ? el("a", { href: url, target: "_blank", rel: "noopener" }, title) : title;
  $(id).replaceChildren(el("strong", {}, heading), ...(detail ? [el("span", {}, detail)] : []));
}

function standIn(frameId, text) {
  $(frameId).replaceChildren(el("div", { className: "stand-in" }, text));
}

const MESSAGES = {
  book: { empty: "Nothing on the currently reading shelf.", error: "Goodreads isn't responding right now." },
  video: { empty: "The YouTube playlist is empty.", error: "YouTube isn't responding right now." },
  song: { empty: "This playlist is empty.", error: "Apple Music isn't responding right now." },
};

function renderBook(book) {
  const standInCover = () => el("div", { className: "stand-in cover" }, book.title);
  const cover = book.cover
    ? el("img", { src: book.cover, alt: `Cover of ${book.title}`, onerror: (e) => e.target.replaceWith(standInCover()) })
    : standInCover();
  $("book-frame").replaceChildren(el("a", { href: book.url, target: "_blank", rel: "noopener" }, cover));
  caption("book-caption", book.title, book.author, book.url);
}

function renderVideo(video) {
  const player = el("iframe", {
    src: `https://www.youtube-nocookie.com/embed/${encodeURIComponent(video.id)}`,
    title: video.title || "Latest addition to Sarah's YouTube playlist",
    allow: "accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
    allowFullscreen: true,
    loading: "lazy",
  });
  $("video-frame").replaceChildren(player);

  const added = video.added ? `Added ${video.added}` : "Latest playlist addition";
  const playlist = el("a", { href: video.playlistUrl, target: "_blank", rel: "noopener" }, "the playlist");
  caption("video-caption", video.title, video.channel, video.url);
  $("video-caption").append(el("span", {}, `${added}, from `, playlist));
}

function renderSong(song) {
  const frame = $("song-frame");
  const art = song.artwork
    ? el("img", { src: song.artwork, alt: song.album ? `Album art for ${song.album}` : "" })
    : el("div", { className: "stand-in" }, song.title);
  frame.replaceChildren(el("a", { href: song.url, target: "_blank", rel: "noopener" }, art));

  if (song.preview) {
    const audio = new Audio();
    audio.preload = "none";
    audio.src = song.preview;
    const button = el("button", { className: "overlay-button", type: "button" });
    const show = (playing) => {
      button.innerHTML = `${playing ? PAUSE : PLAY}${playing ? "Pause" : "Play preview"}`;
    };
    show(false);
    button.onclick = () => (audio.paused ? audio.play() : audio.pause());
    audio.onplay = () => show(true);
    audio.onpause = audio.onended = () => show(false);
    frame.append(button);
  }
  caption("song-caption", song.title, [song.artist, song.album].filter(Boolean).join(", "), song.url);
}

function mark(kind, text, url, order) {
  const link = el("a", { className: `mark ${kind}`, href: url, target: "_blank", rel: "noopener" }, text);
  link.style.setProperty("--order", order);
  link.dataset.target = kind;
  return link;
}

function renderSentence({ book, video, song }) {
  const clauses = [];
  if (book.status === "ok") {
    clauses.push(["is reading ", ["book", book.item.title, book.item.url], book.item.author ? ` by ${book.item.author}` : ""]);
  }
  if (video.status === "ok") {
    clauses.push(["watching ", ["video", shorten(video.item.title), video.item.url], ""]);
  }
  if (song.status === "ok") {
    clauses.push(["ended her playlist on ", ["song", song.item.title, song.item.url], song.item.artist ? ` by ${song.item.artist}` : ""]);
  }

  if (!clauses.length) {
    $("sentence").textContent = `${name}'s shelves are out of reach right now.`;
    return;
  }

  const parts = [`${name} `];
  clauses.forEach(([before, [kind, text, url], after], index) => {
    if (index > 0) parts.push(index === clauses.length - 1 ? (clauses.length > 2 ? ", and " : " and ") : ", ");
    parts.push(before, mark(kind, text, url, index), after);
  });
  parts.push(".");
  $("sentence").replaceChildren(...parts);
}

// Pointing at a phrase or an object picks out its partner and quiets the rest.
function focusKind(kind) {
  if (kind) document.body.dataset.focus = kind;
  else delete document.body.dataset.focus;
  document.querySelectorAll(".object, .mark").forEach((node) => {
    node.classList.toggle("is-focus", (node.dataset.kind ?? node.dataset.target) === kind);
  });
}

function linkHovers() {
  document.querySelectorAll(".mark").forEach((node) => {
    node.addEventListener("pointerenter", () => focusKind(node.dataset.target));
    node.addEventListener("pointerleave", () => focusKind(null));
    node.addEventListener("focus", () => focusKind(node.dataset.target));
    node.addEventListener("blur", () => focusKind(null));
  });
  document.querySelectorAll(".object").forEach((node) => {
    node.addEventListener("pointerenter", () => focusKind(node.dataset.kind));
    node.addEventListener("pointerleave", () => focusKind(null));
  });
}

async function load() {
  let data;
  try {
    const response = await fetch("/api/now");
    if (!response.ok) throw new Error(String(response.status));
    data = await response.json();
  } catch {
    data = { book: { status: "error" }, video: { status: "error" }, song: { status: "error" } };
  }

  const renderers = { book: renderBook, video: renderVideo, song: renderSong };
  for (const kind of Object.keys(renderers)) {
    if (data[kind].status === "ok") renderers[kind](data[kind].item);
    else standIn(`${kind}-frame`, MESSAGES[kind][data[kind].status]);
  }
  renderSentence(data);
  linkHovers();
}

load();
