import { getBook } from "../lib/goodreads.js";
import { getPlaylistVideo } from "../lib/youtube.js";
import { getLastSong } from "../lib/apple.js";

async function settle(load) {
  try {
    const item = await load();
    return item ? { status: "ok", item } : { status: "empty" };
  } catch (error) {
    console.error(error);
    return { status: "error" };
  }
}

export default async function handler(req, res) {
  const [book, video, song] = await Promise.all([settle(getBook), settle(getPlaylistVideo), settle(getLastSong)]);
  const failed = [book, video, song].some(({ status }) => status === "error");
  // Refresh every 15 minutes; retry quickly if a source was down.
  res.setHeader(
    "Cache-Control",
    failed ? "public, s-maxage=60" : "public, s-maxage=900, stale-while-revalidate=86400",
  );
  res.status(200).json({ book, video, song });
}
